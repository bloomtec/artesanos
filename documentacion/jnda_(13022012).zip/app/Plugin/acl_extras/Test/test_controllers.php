<?php

class CommentsController extends Controller {
	function add() {

	}

	function index() {

	}

	function delete() {

	}
	
	function _secret_method() {
		
	}
}

class PostsController extends Controller {

	function index() {

	}

	function add() {

	}

	function edit() {

	}
}

class BigLongNamesController extends Controller {

	function index() {

	}

	function view() {

	}

	function add() {

	}

	function delete() {

	}
}