<?php
App::uses('AppModel', 'Model');
App::uses('AuthComponent', 'Controller/Component');
class Geografico extends AppModel {
	public $useTable = false;
}
