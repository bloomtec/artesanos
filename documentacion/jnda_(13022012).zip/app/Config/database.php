<?php
class DATABASE_CONFIG {

	public  $default = array(
		'datasource' => 'Database/Mysql',
		'persistent' => false,
		'host' => 'localhost',
		'login' => 'jndagobe',
		'password' => '20qtxNm6E4',
		'database' => 'jndagobe_artesanos',
	);

}
