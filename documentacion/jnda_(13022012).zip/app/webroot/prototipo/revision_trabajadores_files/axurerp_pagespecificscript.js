
var PageName = 'revision trabajadores';
var PageId = 'd91c0b9007e847c0a27fa757e692be31'
var PageUrl = 'revision_trabajadores.html'
document.title = 'revision trabajadores';
var PageNotes = 
{
"pageName":"revision trabajadores",
"showNotesNames":"False"}
var $OnLoadVariable = '';

var $CSUM;

var hasQuery = false;
var query = window.location.hash.substring(1);
if (query.length > 0) hasQuery = true;
var vars = query.split("&");
for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split("=");
    if (pair[0].length > 0) eval("$" + pair[0] + " = decodeURIComponent(pair[1]);");
} 

if (hasQuery && $CSUM != 1) {
alert('Prototype Warning: The variable values were too long to pass to this page.\nIf you are using IE, using Firefox will support more data.');
}

function GetQuerystring() {
    return '#OnLoadVariable=' + encodeURIComponent($OnLoadVariable) + '&CSUM=1';
}

function PopulateVariables(value) {
    var d = new Date();
  value = value.replace(/\[\[OnLoadVariable\]\]/g, $OnLoadVariable);
  value = value.replace(/\[\[PageName\]\]/g, PageName);
  value = value.replace(/\[\[GenDay\]\]/g, '6');
  value = value.replace(/\[\[GenMonth\]\]/g, '2');
  value = value.replace(/\[\[GenMonthName\]\]/g, 'febrero');
  value = value.replace(/\[\[GenDayOfWeek\]\]/g, 'lunes');
  value = value.replace(/\[\[GenYear\]\]/g, '2012');
  value = value.replace(/\[\[Day\]\]/g, d.getDate());
  value = value.replace(/\[\[Month\]\]/g, d.getMonth() + 1);
  value = value.replace(/\[\[MonthName\]\]/g, GetMonthString(d.getMonth()));
  value = value.replace(/\[\[DayOfWeek\]\]/g, GetDayString(d.getDay()));
  value = value.replace(/\[\[Year\]\]/g, d.getFullYear());
  return value;
}

function OnLoad(e) {

}

widgetIdToHideFunction['u186'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u189','','none',500);

}

}
widgetIdToHideFunction['u327'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u330','','none',500);

}

}
widgetIdToHideFunction['u162'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u165','','none',500);

}

}
widgetIdToHideFunction['u311'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u314','','none',500);

}

}
widgetIdToHideFunction['u122'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u125','','none',500);

}

}
widgetIdToHideFunction['u106'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u109','','none',500);

}

}
widgetIdToHideFunction['u383'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u386','','none',500);

}

}
widgetIdToHideFunction['u194'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u197','','none',500);

}

}
widgetIdToHideFunction['u335'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u338','','none',500);

}

}
widgetIdToHideFunction['u218'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u221','','none',500);

}

}
widgetIdToHideFunction['u170'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u173','','none',500);

}

}
widgetIdToHideFunction['u359'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u362','','none',500);

}

}
widgetIdToHideFunction['u146'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u149','','none',500);

}

}
widgetIdToHideFunction['u367'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u370','','none',500);

}

}
widgetIdToHideFunction['u114'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u117','','none',500);

}

}
widgetIdToHideFunction['u130'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u133','','none',500);

}

}
widgetIdToHideFunction['u319'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u322','','none',500);

}

}
widgetIdToHideFunction['u154'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u157','','none',500);

}

}
widgetIdToHideFunction['u178'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u181','','none',500);

}

}
widgetIdToHideFunction['u202'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u205','','none',500);

}

}
widgetIdToHideFunction['u343'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u346','','none',500);

}

}
widgetIdToHideFunction['u375'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u378','','none',500);

}

}
widgetIdToHideFunction['u138'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u141','','none',500);

}

}
widgetIdToHideFunction['u210'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u213','','none',500);

}

}
widgetIdToHideFunction['u351'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u354','','none',500);

}

}
var u370 = document.getElementById('u370');

var u167 = document.getElementById('u167');
gv_vAlignTable['u167'] = 'center';
var u299 = document.getElementById('u299');
gv_vAlignTable['u299'] = 'top';
var u36 = document.getElementById('u36');
gv_vAlignTable['u36'] = 'top';
var u180 = document.getElementById('u180');
gv_vAlignTable['u180'] = 'center';
var u400 = document.getElementById('u400');
gv_vAlignTable['u400'] = 'top';
var u216 = document.getElementById('u216');
gv_vAlignTable['u216'] = 'top';
var u194 = document.getElementById('u194');

var u72 = document.getElementById('u72');

var u333 = document.getElementById('u333');
gv_vAlignTable['u333'] = 'top';
var u97 = document.getElementById('u97');

var u152 = document.getElementById('u152');
gv_vAlignTable['u152'] = 'top';
var u231 = document.getElementById('u231');

u231.style.cursor = 'pointer';
if (bIE) u231.attachEvent("onclick", Clicku231);
else u231.addEventListener("click", Clicku231, true);
function Clicku231(e)
{
windowEvent = e;


if (true) {

	self.location.href="modulo_Artesanos.html" + GetQuerystring();

}

}

if (bIE) u231.attachEvent("onmouseover", MouseOveru231);
else u231.addEventListener("mouseover", MouseOveru231, true);
function MouseOveru231(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u231',e)) return;
if (true) {

	SetPanelVisibility('u242','','none',500);

	SetPanelVisibility('u245','hidden','none',500);

	SetPanelVisibility('u239','hidden','none',500);

	SetPanelVisibility('u258','hidden','none',500);

}

}

var u60 = document.getElementById('u60');

var u78 = document.getElementById('u78');
gv_vAlignTable['u78'] = 'top';
var u166 = document.getElementById('u166');

var u298 = document.getElementById('u298');

var u139 = document.getElementById('u139');

u139.style.cursor = 'pointer';
if (bIE) u139.attachEvent("onclick", Clicku139);
else u139.addEventListener("click", Clicku139, true);
function Clicku139(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u138','hidden','fade',500);

}

}

var u201 = document.getElementById('u201');

if (bIE) u201.attachEvent("onfocus", Focusu201);
else u201.addEventListener("focus", Focusu201, true);
function Focusu201(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u202','','fade',500);

}

}

var u1 = document.getElementById('u1');
gv_vAlignTable['u1'] = 'center';
var u215 = document.getElementById('u215');
gv_vAlignTable['u215'] = 'center';
var u193 = document.getElementById('u193');

if (bIE) u193.attachEvent("onfocus", Focusu193);
else u193.addEventListener("focus", Focusu193, true);
function Focusu193(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u194','','fade',500);

}

}

var u11 = document.getElementById('u11');

var u126 = document.getElementById('u126');

var u413 = document.getElementById('u413');
gv_vAlignTable['u413'] = 'center';
var u332 = document.getElementById('u332');
gv_vAlignTable['u332'] = 'center';
var u151 = document.getElementById('u151');
gv_vAlignTable['u151'] = 'center';
var u202 = document.getElementById('u202');

var u26 = document.getElementById('u26');

var u389 = document.getElementById('u389');
gv_vAlignTable['u389'] = 'top';
var u165 = document.getElementById('u165');

var u378 = document.getElementById('u378');

var u138 = document.getElementById('u138');

var u100 = document.getElementById('u100');
gv_vAlignTable['u100'] = 'top';
var u54 = document.getElementById('u54');
gv_vAlignTable['u54'] = 'top';
var u236 = document.getElementById('u236');
gv_vAlignTable['u236'] = 'center';
var u214 = document.getElementById('u214');

var u192 = document.getElementById('u192');
gv_vAlignTable['u192'] = 'top';
var u67 = document.getElementById('u67');
gv_vAlignTable['u67'] = 'top';
var u269 = document.getElementById('u269');
gv_vAlignTable['u269'] = 'top';
var u331 = document.getElementById('u331');

var u321 = document.getElementById('u321');
gv_vAlignTable['u321'] = 'center';
var u150 = document.getElementById('u150');

var u287 = document.getElementById('u287');

var u48 = document.getElementById('u48');
gv_vAlignTable['u48'] = 'top';
var u327 = document.getElementById('u327');

var u340 = document.getElementById('u340');
gv_vAlignTable['u340'] = 'center';
var u24 = document.getElementById('u24');

var u80 = document.getElementById('u80');
gv_vAlignTable['u80'] = 'top';
var u65 = document.getElementById('u65');
gv_vAlignTable['u65'] = 'top';
var u346 = document.getElementById('u346');

var u318 = document.getElementById('u318');

if (bIE) u318.attachEvent("onfocus", Focusu318);
else u318.addEventListener("focus", Focusu318, true);
function Focusu318(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u319','','fade',500);

}

}

var u365 = document.getElementById('u365');
gv_vAlignTable['u365'] = 'top';
var u113 = document.getElementById('u113');

if (bIE) u113.attachEvent("onfocus", Focusu113);
else u113.addEventListener("focus", Focusu113, true);
function Focusu113(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u114','','fade',500);

}

}

var u268 = document.getElementById('u268');
gv_vAlignTable['u268'] = 'top';
var u330 = document.getElementById('u330');

var u227 = document.getElementById('u227');

u227.style.cursor = 'pointer';
if (bIE) u227.attachEvent("onclick", Clicku227);
else u227.addEventListener("click", Clicku227, true);
function Clicku227(e)
{
windowEvent = e;


if (true) {

	self.location.href="pagina_de_inicio.html" + GetQuerystring();

}

}

var u42 = document.getElementById('u42');

var u159 = document.getElementById('u159');
gv_vAlignTable['u159'] = 'center';
var u163 = document.getElementById('u163');

u163.style.cursor = 'pointer';
if (bIE) u163.attachEvent("onclick", Clicku163);
else u163.addEventListener("click", Clicku163, true);
function Clicku163(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u162','hidden','fade',500);

}

}

var u63 = document.getElementById('u63');
gv_vAlignTable['u63'] = 'top';
var u326 = document.getElementById('u326');

if (bIE) u326.attachEvent("onfocus", Focusu326);
else u326.addEventListener("focus", Focusu326, true);
function Focusu326(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u327','','fade',500);

}

}

var u177 = document.getElementById('u177');

if (bIE) u177.attachEvent("onfocus", Focusu177);
else u177.addEventListener("focus", Focusu177, true);
function Focusu177(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u178','','fade',500);

}

}

var u37 = document.getElementById('u37');
gv_vAlignTable['u37'] = 'top';
var u93 = document.getElementById('u93');

var u112 = document.getElementById('u112');
gv_vAlignTable['u112'] = 'top';
var u46 = document.getElementById('u46');
gv_vAlignTable['u46'] = 'top';
var u307 = document.getElementById('u307');
gv_vAlignTable['u307'] = 'top';
var u285 = document.getElementById('u285');

var u18 = document.getElementById('u18');

u18.style.cursor = 'pointer';
if (bIE) u18.attachEvent("onclick", Clicku18);
else u18.addEventListener("click", Clicku18, true);
function Clicku18(e)
{
windowEvent = e;


if (true) {

	self.location.href="mis_inspecciones.html" + GetQuerystring();

}

}

var u50 = document.getElementById('u50');
gv_vAlignTable['u50'] = 'top';
var u74 = document.getElementById('u74');

var u162 = document.getElementById('u162');

var u357 = document.getElementById('u357');
gv_vAlignTable['u357'] = 'top';
var u79 = document.getElementById('u79');

var u176 = document.getElementById('u176');
gv_vAlignTable['u176'] = 'top';
var u55 = document.getElementById('u55');

var u411 = document.getElementById('u411');

var u149 = document.getElementById('u149');

var u111 = document.getElementById('u111');
gv_vAlignTable['u111'] = 'center';
var u391 = document.getElementById('u391');

var u306 = document.getElementById('u306');

var u284 = document.getElementById('u284');

var u12 = document.getElementById('u12');
gv_vAlignTable['u12'] = 'center';
var u342 = document.getElementById('u342');

if (bIE) u342.attachEvent("onfocus", Focusu342);
else u342.addEventListener("focus", Focusu342, true);
function Focusu342(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u343','','fade',500);

}

}

var u161 = document.getElementById('u161');

if (bIE) u161.attachEvent("onfocus", Focusu161);
else u161.addEventListener("focus", Focusu161, true);
function Focusu161(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u162','','fade',500);

}

}

var u329 = document.getElementById('u329');
gv_vAlignTable['u329'] = 'center';
var u356 = document.getElementById('u356');
gv_vAlignTable['u356'] = 'center';
var u175 = document.getElementById('u175');
gv_vAlignTable['u175'] = 'center';
var u229 = document.getElementById('u229');

u229.style.cursor = 'pointer';
if (bIE) u229.attachEvent("onclick", Clicku229);
else u229.addEventListener("click", Clicku229, true);
function Clicku229(e)
{
windowEvent = e;


if (true) {

	self.location.href="modulo_Usuarios.html" + GetQuerystring();

}

}

if (bIE) u229.attachEvent("onmouseover", MouseOveru229);
else u229.addEventListener("mouseover", MouseOveru229, true);
function MouseOveru229(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u229',e)) return;
if (true) {

	SetPanelVisibility('u239','','none',500);

	SetPanelVisibility('u242','hidden','none',500);

	SetPanelVisibility('u245','hidden','none',500);

	SetPanelVisibility('u258','','none',500);

}

}

var u148 = document.getElementById('u148');
gv_vAlignTable['u148'] = 'center';
var u110 = document.getElementById('u110');

var u348 = document.getElementById('u348');
gv_vAlignTable['u348'] = 'center';
var u305 = document.getElementById('u305');
gv_vAlignTable['u305'] = 'top';
var u283 = document.getElementById('u283');

var u20 = document.getElementById('u20');

var u124 = document.getElementById('u124');
gv_vAlignTable['u124'] = 'center';
var u279 = document.getElementById('u279');

var u241 = document.getElementById('u241');
gv_vAlignTable['u241'] = 'center';
var u160 = document.getElementById('u160');
gv_vAlignTable['u160'] = 'top';
var u297 = document.getElementById('u297');
gv_vAlignTable['u297'] = 'top';
var u8 = document.getElementById('u8');
gv_vAlignTable['u8'] = 'top';
var u49 = document.getElementById('u49');

var u355 = document.getElementById('u355');

var u25 = document.getElementById('u25');

var u309 = document.getElementById('u309');
gv_vAlignTable['u309'] = 'top';
var u228 = document.getElementById('u228');
gv_vAlignTable['u228'] = 'center';
var u81 = document.getElementById('u81');

var u88 = document.getElementById('u88');
gv_vAlignTable['u88'] = 'top';
var u304 = document.getElementById('u304');

var u282 = document.getElementById('u282');

var u76 = document.getElementById('u76');
gv_vAlignTable['u76'] = 'top';
var u123 = document.getElementById('u123');

u123.style.cursor = 'pointer';
if (bIE) u123.attachEvent("onclick", Clicku123);
else u123.addEventListener("click", Clicku123, true);
function Clicku123(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u122','hidden','fade',500);

}

}

var u278 = document.getElementById('u278');

var u240 = document.getElementById('u240');

u240.style.cursor = 'pointer';
if (bIE) u240.attachEvent("onclick", Clicku240);
else u240.addEventListener("click", Clicku240, true);
function Clicku240(e)
{
windowEvent = e;


if (true) {

	self.location.href="agregar_usuario.html" + GetQuerystring();

}

}

var u296 = document.getElementById('u296');

var u137 = document.getElementById('u137');

if (bIE) u137.attachEvent("onfocus", Focusu137);
else u137.addEventListener("focus", Focusu137, true);
function Focusu137(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u138','','fade',500);

}

}

var u33 = document.getElementById('u33');

var u254 = document.getElementById('u254');

u254.style.cursor = 'pointer';
if (bIE) u254.attachEvent("onclick", Clicku254);
else u254.addEventListener("click", Clicku254, true);
function Clicku254(e)
{
windowEvent = e;


if (true) {

	self.location.href="reporte_de_inspeccion_por_estado_para_supervision.html" + GetQuerystring();

}

}

var u173 = document.getElementById('u173');

var u343 = document.getElementById('u343');

var u213 = document.getElementById('u213');

var u303 = document.getElementById('u303');
gv_vAlignTable['u303'] = 'top';
var u281 = document.getElementById('u281');

var u94 = document.getElementById('u94');
gv_vAlignTable['u94'] = 'top';
var u122 = document.getElementById('u122');

var u358 = document.getElementById('u358');

if (bIE) u358.attachEvent("onfocus", Focusu358);
else u358.addEventListener("focus", Focusu358, true);
function Focusu358(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u359','','fade',500);

}

}

var u5 = document.getElementById('u5');
gv_vAlignTable['u5'] = 'top';
var u317 = document.getElementById('u317');
gv_vAlignTable['u317'] = 'top';
var u295 = document.getElementById('u295');
gv_vAlignTable['u295'] = 'top';
var u136 = document.getElementById('u136');
gv_vAlignTable['u136'] = 'top';
var u51 = document.getElementById('u51');

var u109 = document.getElementById('u109');

var u253 = document.getElementById('u253');
gv_vAlignTable['u253'] = 'center';
var u172 = document.getElementById('u172');
gv_vAlignTable['u172'] = 'center';
var u410 = document.getElementById('u410');
gv_vAlignTable['u410'] = 'top';
var u359 = document.getElementById('u359');

var u267 = document.getElementById('u267');

var u399 = document.getElementById('u399');

var u302 = document.getElementById('u302');

var u280 = document.getElementById('u280');

var u121 = document.getElementById('u121');

if (bIE) u121.attachEvent("onfocus", Focusu121);
else u121.addEventListener("focus", Focusu121, true);
function Focusu121(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u122','','fade',500);

}

}

var u414 = document.getElementById('u414');

var u409 = document.getElementById('u409');

var u316 = document.getElementById('u316');
gv_vAlignTable['u316'] = 'center';
var u294 = document.getElementById('u294');

var u135 = document.getElementById('u135');
gv_vAlignTable['u135'] = 'center';
var u108 = document.getElementById('u108');
gv_vAlignTable['u108'] = 'center';
var u252 = document.getElementById('u252');

u252.style.cursor = 'pointer';
if (bIE) u252.attachEvent("onclick", Clicku252);
else u252.addEventListener("click", Clicku252, true);
function Clicku252(e)
{
windowEvent = e;


if (true) {

	self.location.href="reporte_de_inspecciones.html" + GetQuerystring();

}

}

var u171 = document.getElementById('u171');

u171.style.cursor = 'pointer';
if (bIE) u171.attachEvent("onclick", Clicku171);
else u171.addEventListener("click", Clicku171, true);
function Clicku171(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u170','hidden','fade',500);

}

}

var u191 = document.getElementById('u191');
gv_vAlignTable['u191'] = 'center';
var u386 = document.getElementById('u386');

var u266 = document.getElementById('u266');

var u64 = document.getElementById('u64');
gv_vAlignTable['u64'] = 'top';
var u239 = document.getElementById('u239');

var u301 = document.getElementById('u301');
gv_vAlignTable['u301'] = 'top';
var u120 = document.getElementById('u120');
gv_vAlignTable['u120'] = 'top';
var u2 = document.getElementById('u2');

var u315 = document.getElementById('u315');

var u293 = document.getElementById('u293');
gv_vAlignTable['u293'] = 'top';
var u21 = document.getElementById('u21');

var u134 = document.getElementById('u134');

var u251 = document.getElementById('u251');
gv_vAlignTable['u251'] = 'center';
var u170 = document.getElementById('u170');

var u373 = document.getElementById('u373');
gv_vAlignTable['u373'] = 'top';
var u265 = document.getElementById('u265');

var u82 = document.getElementById('u82');
gv_vAlignTable['u82'] = 'top';
var u16 = document.getElementById('u16');

u16.style.cursor = 'pointer';
if (bIE) u16.attachEvent("onclick", Clicku16);
else u16.addEventListener("click", Clicku16, true);
function Clicku16(e)
{
windowEvent = e;


if (true) {

	self.location.href="revision_taller.html" + GetQuerystring();

}

}

var u238 = document.getElementById('u238');
gv_vAlignTable['u238'] = 'center';
var u200 = document.getElementById('u200');
gv_vAlignTable['u200'] = 'top';
var u314 = document.getElementById('u314');

var u292 = document.getElementById('u292');

var u77 = document.getElementById('u77');

var u133 = document.getElementById('u133');

var u369 = document.getElementById('u369');
gv_vAlignTable['u369'] = 'center';
var u250 = document.getElementById('u250');

u250.style.cursor = 'pointer';
if (bIE) u250.attachEvent("onclick", Clicku250);
else u250.addEventListener("click", Clicku250, true);
function Clicku250(e)
{
windowEvent = e;


if (true) {

	self.location.href="reporte_de_calificaciones_artesano.html" + GetQuerystring();

}

}

var u387 = document.getElementById('u387');

var u147 = document.getElementById('u147');

u147.style.cursor = 'pointer';
if (bIE) u147.attachEvent("onclick", Clicku147);
else u147.addEventListener("click", Clicku147, true);
function Clicku147(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u146','hidden','fade',500);

}

}

var u58 = document.getElementById('u58');

var u34 = document.getElementById('u34');

var u90 = document.getElementById('u90');
gv_vAlignTable['u90'] = 'top';
var u61 = document.getElementById('u61');
gv_vAlignTable['u61'] = 'top';
var u164 = document.getElementById('u164');
gv_vAlignTable['u164'] = 'center';
var u95 = document.getElementById('u95');

var u132 = document.getElementById('u132');
gv_vAlignTable['u132'] = 'center';
var u368 = document.getElementById('u368');

u368.style.cursor = 'pointer';
if (bIE) u368.attachEvent("onclick", Clicku368);
else u368.addEventListener("click", Clicku368, true);
function Clicku368(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u367','hidden','fade',500);

}

}

var u255 = document.getElementById('u255');
gv_vAlignTable['u255'] = 'center';
var u146 = document.getElementById('u146');

var u52 = document.getElementById('u52');

var u125 = document.getElementById('u125');

var u263 = document.getElementById('u263');

var u91 = document.getElementById('u91');

var u277 = document.getElementById('u277');

var u388 = document.getElementById('u388');
gv_vAlignTable['u388'] = 'center';
var u47 = document.getElementById('u47');

var u212 = document.getElementById('u212');
gv_vAlignTable['u212'] = 'center';
var u131 = document.getElementById('u131');

u131.style.cursor = 'pointer';
if (bIE) u131.attachEvent("onclick", Clicku131);
else u131.addEventListener("click", Clicku131, true);
function Clicku131(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u130','hidden','fade',500);

}

}

var u407 = document.getElementById('u407');

var u385 = document.getElementById('u385');
gv_vAlignTable['u385'] = 'center';
var u28 = document.getElementById('u28');

var u145 = document.getElementById('u145');

if (bIE) u145.attachEvent("onfocus", Focusu145);
else u145.addEventListener("focus", Focusu145, true);
function Focusu145(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u146','','fade',500);

}

}

var u118 = document.getElementById('u118');

var u262 = document.getElementById('u262');
gv_vAlignTable['u262'] = 'top';
var u322 = document.getElementById('u322');

var u276 = document.getElementById('u276');

var u89 = document.getElementById('u89');

var u249 = document.getElementById('u249');
gv_vAlignTable['u249'] = 'center';
var u211 = document.getElementById('u211');

u211.style.cursor = 'pointer';
if (bIE) u211.attachEvent("onclick", Clicku211);
else u211.addEventListener("click", Clicku211, true);
function Clicku211(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u210','hidden','fade',500);

}

}

var u130 = document.getElementById('u130');

var u345 = document.getElementById('u345');
gv_vAlignTable['u345'] = 'center';
var u85 = document.getElementById('u85');

var u406 = document.getElementById('u406');
gv_vAlignTable['u406'] = 'top';
var u384 = document.getElementById('u384');

u384.style.cursor = 'pointer';
if (bIE) u384.attachEvent("onclick", Clicku384);
else u384.addEventListener("click", Clicku384, true);
function Clicku384(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u383','hidden','fade',500);

}

}

var u22 = document.getElementById('u22');

var u144 = document.getElementById('u144');
gv_vAlignTable['u144'] = 'top';
var u261 = document.getElementById('u261');

var u43 = document.getElementById('u43');
gv_vAlignTable['u43'] = 'top';
var u275 = document.getElementById('u275');

var u17 = document.getElementById('u17');
gv_vAlignTable['u17'] = 'center';
var u248 = document.getElementById('u248');

u248.style.cursor = 'pointer';
if (bIE) u248.attachEvent("onclick", Clicku248);
else u248.addEventListener("click", Clicku248, true);
function Clicku248(e)
{
windowEvent = e;


if (true) {

	self.location.href="reporte_de_calificaciones_por_operador.html" + GetQuerystring();

}

}

var u210 = document.getElementById('u210');

var u325 = document.getElementById('u325');
gv_vAlignTable['u325'] = 'top';
var u107 = document.getElementById('u107');

u107.style.cursor = 'pointer';
if (bIE) u107.attachEvent("onclick", Clicku107);
else u107.addEventListener("click", Clicku107, true);
function Clicku107(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u106','hidden','fade',500);

}

}

var u44 = document.getElementById('u44');

var u405 = document.getElementById('u405');

var u383 = document.getElementById('u383');

var u30 = document.getElementById('u30');

var u224 = document.getElementById('u224');
gv_vAlignTable['u224'] = 'top';
var u143 = document.getElementById('u143');
gv_vAlignTable['u143'] = 'center';
var u379 = document.getElementById('u379');

var u341 = document.getElementById('u341');
gv_vAlignTable['u341'] = 'top';
var u260 = document.getElementById('u260');
gv_vAlignTable['u260'] = 'center';
var u397 = document.getElementById('u397');

var u9 = document.getElementById('u9');
gv_vAlignTable['u9'] = 'top';
var u157 = document.getElementById('u157');

var u59 = document.getElementById('u59');
gv_vAlignTable['u59'] = 'top';
var u189 = document.getElementById('u189');

var u35 = document.getElementById('u35');
gv_vAlignTable['u35'] = 'top';
var u274 = document.getElementById('u274');
gv_vAlignTable['u274'] = 'top';
var u328 = document.getElementById('u328');

u328.style.cursor = 'pointer';
if (bIE) u328.attachEvent("onclick", Clicku328);
else u328.addEventListener("click", Clicku328, true);
function Clicku328(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u327','hidden','fade',500);

}

}

var u106 = document.getElementById('u106');

var u404 = document.getElementById('u404');
gv_vAlignTable['u404'] = 'top';
var u382 = document.getElementById('u382');

if (bIE) u382.attachEvent("onfocus", Focusu382);
else u382.addEventListener("focus", Focusu382, true);
function Focusu382(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u383','','fade',500);

}

}

var u223 = document.getElementById('u223');
gv_vAlignTable['u223'] = 'center';
var u142 = document.getElementById('u142');

var u86 = document.getElementById('u86');
gv_vAlignTable['u86'] = 'top';
var u70 = document.getElementById('u70');

var u396 = document.getElementById('u396');
gv_vAlignTable['u396'] = 'top';
var u237 = document.getElementById('u237');

u237.style.cursor = 'pointer';
if (bIE) u237.attachEvent("onclick", Clicku237);
else u237.addEventListener("click", Clicku237, true);
function Clicku237(e)
{
windowEvent = e;


if (true) {

	self.location.href="reporte_de_artesanos.html" + GetQuerystring();

}

}

if (bIE) u237.attachEvent("onmouseover", MouseOveru237);
else u237.addEventListener("mouseover", MouseOveru237, true);
function MouseOveru237(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u237',e)) return;
if (true) {

	SetPanelVisibility('u245','','none',500);

	SetPanelVisibility('u242','hidden','none',500);

	SetPanelVisibility('u239','hidden','none',500);

	SetPanelVisibility('u258','hidden','none',500);

}

}

var u156 = document.getElementById('u156');
gv_vAlignTable['u156'] = 'center';
var u188 = document.getElementById('u188');
gv_vAlignTable['u188'] = 'center';
var u354 = document.getElementById('u354');

var u273 = document.getElementById('u273');
gv_vAlignTable['u273'] = 'top';
var u105 = document.getElementById('u105');

if (bIE) u105.attachEvent("onfocus", Focusu105);
else u105.addEventListener("focus", Focusu105, true);
function Focusu105(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u106','','fade',500);

}

}

var u403 = document.getElementById('u403');

var u381 = document.getElementById('u381');
gv_vAlignTable['u381'] = 'top';
var u222 = document.getElementById('u222');

var u311 = document.getElementById('u311');

var u6 = document.getElementById('u6');
gv_vAlignTable['u6'] = 'top';
var u395 = document.getElementById('u395');

var u29 = document.getElementById('u29');

var u155 = document.getElementById('u155');

u155.style.cursor = 'pointer';
if (bIE) u155.attachEvent("onclick", Clicku155);
else u155.addEventListener("click", Clicku155, true);
function Clicku155(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u154','hidden','fade',500);

}

}

var u209 = document.getElementById('u209');

if (bIE) u209.attachEvent("onfocus", Focusu209);
else u209.addEventListener("focus", Focusu209, true);
function Focusu209(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u210','','fade',500);

}

}

var u353 = document.getElementById('u353');
gv_vAlignTable['u353'] = 'center';
var u272 = document.getElementById('u272');
gv_vAlignTable['u272'] = 'top';
var u402 = document.getElementById('u402');
gv_vAlignTable['u402'] = 'top';
var u336 = document.getElementById('u336');

u336.style.cursor = 'pointer';
if (bIE) u336.attachEvent("onclick", Clicku336);
else u336.addEventListener("click", Clicku336, true);
function Clicku336(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u335','hidden','fade',500);

}

}

var u19 = document.getElementById('u19');
gv_vAlignTable['u19'] = 'center';
var u367 = document.getElementById('u367');

var u104 = document.getElementById('u104');
gv_vAlignTable['u104'] = 'top';
var u308 = document.getElementById('u308');

var u259 = document.getElementById('u259');

u259.style.cursor = 'pointer';
if (bIE) u259.attachEvent("onclick", Clicku259);
else u259.addEventListener("click", Clicku259, true);
function Clicku259(e)
{
windowEvent = e;


if (true) {

	self.location.href="mis_inspecciones.html" + GetQuerystring();

}

}

var u380 = document.getElementById('u380');
gv_vAlignTable['u380'] = 'center';
var u221 = document.getElementById('u221');

var u119 = document.getElementById('u119');
gv_vAlignTable['u119'] = 'center';
var u232 = document.getElementById('u232');
gv_vAlignTable['u232'] = 'center';
var u416 = document.getElementById('u416');
gv_vAlignTable['u416'] = 'center';
var u394 = document.getElementById('u394');

var u235 = document.getElementById('u235');

u235.style.cursor = 'pointer';
if (bIE) u235.attachEvent("onclick", Clicku235);
else u235.addEventListener("click", Clicku235, true);
function Clicku235(e)
{
windowEvent = e;


if (true) {

	self.location.href="parametros.html" + GetQuerystring();

}

}

if (bIE) u235.attachEvent("onmouseover", MouseOveru235);
else u235.addEventListener("mouseover", MouseOveru235, true);
function MouseOveru235(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u235',e)) return;
if (true) {

	SetPanelVisibility('u239','hidden','none',500);

	SetPanelVisibility('u245','hidden','none',500);

	SetPanelVisibility('u242','hidden','none',500);

	SetPanelVisibility('u258','hidden','none',500);

}

}

var u75 = document.getElementById('u75');

var u13 = document.getElementById('u13');
gv_vAlignTable['u13'] = 'top';
var u208 = document.getElementById('u208');
gv_vAlignTable['u208'] = 'top';
var u352 = document.getElementById('u352');

u352.style.cursor = 'pointer';
if (bIE) u352.attachEvent("onclick", Clicku352);
else u352.addEventListener("click", Clicku352, true);
function Clicku352(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u351','hidden','fade',500);

}

}

var u271 = document.getElementById('u271');
gv_vAlignTable['u271'] = 'top';
var u312 = document.getElementById('u312');

u312.style.cursor = 'pointer';
if (bIE) u312.attachEvent("onclick", Clicku312);
else u312.addEventListener("click", Clicku312, true);
function Clicku312(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u311','hidden','fade',500);

}

}

var u366 = document.getElementById('u366');

if (bIE) u366.attachEvent("onfocus", Focusu366);
else u366.addEventListener("focus", Focusu366, true);
function Focusu366(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u367','','fade',500);

}

}

var u98 = document.getElementById('u98');
gv_vAlignTable['u98'] = 'top';
var u103 = document.getElementById('u103');

var u339 = document.getElementById('u339');

var u401 = document.getElementById('u401');
gv_vAlignTable['u401'] = 'top';
var u158 = document.getElementById('u158');

var u220 = document.getElementById('u220');
gv_vAlignTable['u220'] = 'center';
var u3 = document.getElementById('u3');
gv_vAlignTable['u3'] = 'top';
var u117 = document.getElementById('u117');

var u415 = document.getElementById('u415');

u415.style.cursor = 'pointer';
if (bIE) u415.attachEvent("onclick", Clicku415);
else u415.addEventListener("click", Clicku415, true);
function Clicku415(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u414','hidden','none',500);

}

}

var u393 = document.getElementById('u393');

var u31 = document.getElementById('u31');

var u234 = document.getElementById('u234');
gv_vAlignTable['u234'] = 'center';
var u73 = document.getElementById('u73');
gv_vAlignTable['u73'] = 'top';
var u351 = document.getElementById('u351');

var u270 = document.getElementById('u270');
gv_vAlignTable['u270'] = 'top';
var u199 = document.getElementById('u199');
gv_vAlignTable['u199'] = 'center';
var u319 = document.getElementById('u319');

var u92 = document.getElementById('u92');
gv_vAlignTable['u92'] = 'top';
var u102 = document.getElementById('u102');
gv_vAlignTable['u102'] = 'top';
var u56 = document.getElementById('u56');

var u300 = document.getElementById('u300');

var u116 = document.getElementById('u116');
gv_vAlignTable['u116'] = 'center';
var u186 = document.getElementById('u186');

var u392 = document.getElementById('u392');

var u233 = document.getElementById('u233');

u233.style.cursor = 'pointer';
if (bIE) u233.attachEvent("onclick", Clicku233);
else u233.addEventListener("click", Clicku233, true);
function Clicku233(e)
{
windowEvent = e;


if (true) {

	self.location.href="auditoria.html" + GetQuerystring();

}

}

if (bIE) u233.attachEvent("onmouseover", MouseOveru233);
else u233.addEventListener("mouseover", MouseOveru233, true);
function MouseOveru233(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u233',e)) return;
if (true) {

	SetPanelVisibility('u239','hidden','none',500);

	SetPanelVisibility('u242','hidden','none',500);

	SetPanelVisibility('u245','hidden','none',500);

	SetPanelVisibility('u258','hidden','none',500);

}

}

var u87 = document.getElementById('u87');

var u350 = document.getElementById('u350');

if (bIE) u350.attachEvent("onfocus", Focusu350);
else u350.addEventListener("focus", Focusu350, true);
function Focusu350(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u351','','fade',500);

}

}

var u347 = document.getElementById('u347');

var u247 = document.getElementById('u247');
gv_vAlignTable['u247'] = 'center';
var u68 = document.getElementById('u68');

var u226 = document.getElementById('u226');
gv_vAlignTable['u226'] = 'center';
var u198 = document.getElementById('u198');

var u364 = document.getElementById('u364');
gv_vAlignTable['u364'] = 'center';
var u101 = document.getElementById('u101');

var u0 = document.getElementById('u0');

var u190 = document.getElementById('u190');

var u115 = document.getElementById('u115');

u115.style.cursor = 'pointer';
if (bIE) u115.attachEvent("onclick", Clicku115);
else u115.addEventListener("click", Clicku115, true);
function Clicku115(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u114','hidden','fade',500);

}

}

var u313 = document.getElementById('u313');
gv_vAlignTable['u313'] = 'center';
var u291 = document.getElementById('u291');
gv_vAlignTable['u291'] = 'top';
var u7 = document.getElementById('u7');
gv_vAlignTable['u7'] = 'top';
var u246 = document.getElementById('u246');

u246.style.cursor = 'pointer';
if (bIE) u246.attachEvent("onclick", Clicku246);
else u246.addEventListener("click", Clicku246, true);
function Clicku246(e)
{
windowEvent = e;


if (true) {

	self.location.href="reporte_de_artesanos.html" + GetQuerystring();

}

}

var u62 = document.getElementById('u62');

var u219 = document.getElementById('u219');

u219.style.cursor = 'pointer';
if (bIE) u219.attachEvent("onclick", Clicku219);
else u219.addEventListener("click", Clicku219, true);
function Clicku219(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u218','hidden','fade',500);

}

}

var u363 = document.getElementById('u363');

var u377 = document.getElementById('u377');
gv_vAlignTable['u377'] = 'center';
var u372 = document.getElementById('u372');
gv_vAlignTable['u372'] = 'center';
var u114 = document.getElementById('u114');

var u57 = document.getElementById('u57');
gv_vAlignTable['u57'] = 'top';
var u169 = document.getElementById('u169');

if (bIE) u169.attachEvent("onfocus", Focusu169);
else u169.addEventListener("focus", Focusu169, true);
function Focusu169(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u170','','fade',500);

}

}

var u290 = document.getElementById('u290');

var u408 = document.getElementById('u408');
gv_vAlignTable['u408'] = 'top';
var u187 = document.getElementById('u187');

u187.style.cursor = 'pointer';
if (bIE) u187.attachEvent("onclick", Clicku187);
else u187.addEventListener("click", Clicku187, true);
function Clicku187(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u186','hidden','fade',500);

}

}

var u38 = document.getElementById('u38');
gv_vAlignTable['u38'] = 'top';
var u245 = document.getElementById('u245');

var u412 = document.getElementById('u412');

u412.style.cursor = 'pointer';
if (bIE) u412.attachEvent("onclick", Clicku412);
else u412.addEventListener("click", Clicku412, true);
function Clicku412(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u414','','none',500);

}

}

var u14 = document.getElementById('u14');
gv_vAlignTable['u14'] = 'top';
var u218 = document.getElementById('u218');

var u362 = document.getElementById('u362');

var u376 = document.getElementById('u376');

u376.style.cursor = 'pointer';
if (bIE) u376.attachEvent("onclick", Clicku376);
else u376.addEventListener("click", Clicku376, true);
function Clicku376(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u375','hidden','fade',500);

}

}

var u99 = document.getElementById('u99');

var u286 = document.getElementById('u286');

var u349 = document.getElementById('u349');
gv_vAlignTable['u349'] = 'top';
var u168 = document.getElementById('u168');
gv_vAlignTable['u168'] = 'top';
var u230 = document.getElementById('u230');
gv_vAlignTable['u230'] = 'center';
var u127 = document.getElementById('u127');
gv_vAlignTable['u127'] = 'center';
var u338 = document.getElementById('u338');

var u32 = document.getElementById('u32');

var u244 = document.getElementById('u244');
gv_vAlignTable['u244'] = 'center';
var u390 = document.getElementById('u390');
gv_vAlignTable['u390'] = 'top';
var u361 = document.getElementById('u361');
gv_vAlignTable['u361'] = 'center';
var u375 = document.getElementById('u375');

var u27 = document.getElementById('u27');

var u83 = document.getElementById('u83');
gv_vAlignTable['u83'] = 'top';
var u310 = document.getElementById('u310');

if (bIE) u310.attachEvent("onfocus", Focusu310);
else u310.addEventListener("focus", Focusu310, true);
function Focusu310(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u311','','fade',500);

}

}

var u207 = document.getElementById('u207');
gv_vAlignTable['u207'] = 'center';
var u185 = document.getElementById('u185');

if (bIE) u185.attachEvent("onfocus", Focusu185);
else u185.addEventListener("focus", Focusu185, true);
function Focusu185(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u186','','fade',500);

}

}

var u40 = document.getElementById('u40');
gv_vAlignTable['u40'] = 'top';
var u324 = document.getElementById('u324');
gv_vAlignTable['u324'] = 'center';
var u243 = document.getElementById('u243');

u243.style.cursor = 'pointer';
if (bIE) u243.attachEvent("onclick", Clicku243);
else u243.addEventListener("click", Clicku243, true);
function Clicku243(e)
{
windowEvent = e;


if (true) {

	self.location.href="registrar_artesano.html" + GetQuerystring();

}

}

var u360 = document.getElementById('u360');

u360.style.cursor = 'pointer';
if (bIE) u360.attachEvent("onclick", Clicku360);
else u360.addEventListener("click", Clicku360, true);
function Clicku360(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u359','hidden','fade',500);

}

}

var u257 = document.getElementById('u257');
gv_vAlignTable['u257'] = 'center';
var u69 = document.getElementById('u69');
gv_vAlignTable['u69'] = 'top';
var u289 = document.getElementById('u289');

var u45 = document.getElementById('u45');
gv_vAlignTable['u45'] = 'top';
var u374 = document.getElementById('u374');

if (bIE) u374.attachEvent("onfocus", Focusu374);
else u374.addEventListener("focus", Focusu374, true);
function Focusu374(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u375','','fade',500);

}

}

var u206 = document.getElementById('u206');

var u184 = document.getElementById('u184');
gv_vAlignTable['u184'] = 'top';
var u323 = document.getElementById('u323');

var u242 = document.getElementById('u242');

var u96 = document.getElementById('u96');
gv_vAlignTable['u96'] = 'top';
var u344 = document.getElementById('u344');

u344.style.cursor = 'pointer';
if (bIE) u344.attachEvent("onclick", Clicku344);
else u344.addEventListener("click", Clicku344, true);
function Clicku344(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u343','hidden','fade',500);

}

}

var u337 = document.getElementById('u337');
gv_vAlignTable['u337'] = 'center';
var u256 = document.getElementById('u256');

u256.style.cursor = 'pointer';
if (bIE) u256.attachEvent("onclick", Clicku256);
else u256.addEventListener("click", Clicku256, true);
function Clicku256(e)
{
windowEvent = e;


if (true) {

	self.location.href="reporte_estadistico_de_calificaciones.html" + GetQuerystring();

}

}

var u53 = document.getElementById('u53');

var u129 = document.getElementById('u129');

if (bIE) u129.attachEvent("onfocus", Focusu129);
else u129.addEventListener("focus", Focusu129, true);
function Focusu129(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u130','','fade',500);

}

}

var u174 = document.getElementById('u174');

var u205 = document.getElementById('u205');

var u183 = document.getElementById('u183');
gv_vAlignTable['u183'] = 'center';
var u10 = document.getElementById('u10');
gv_vAlignTable['u10'] = 'top';
var u179 = document.getElementById('u179');

u179.style.cursor = 'pointer';
if (bIE) u179.attachEvent("onclick", Clicku179);
else u179.addEventListener("click", Clicku179, true);
function Clicku179(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u178','hidden','fade',500);

}

}

var u141 = document.getElementById('u141');

var u197 = document.getElementById('u197');

var u39 = document.getElementById('u39');

var u71 = document.getElementById('u71');
gv_vAlignTable['u71'] = 'top';
var u15 = document.getElementById('u15');

var u128 = document.getElementById('u128');
gv_vAlignTable['u128'] = 'top';
var u288 = document.getElementById('u288');

var u398 = document.getElementById('u398');
gv_vAlignTable['u398'] = 'top';
var u204 = document.getElementById('u204');
gv_vAlignTable['u204'] = 'center';
var u182 = document.getElementById('u182');

var u66 = document.getElementById('u66');
gv_vAlignTable['u66'] = 'top';
var u178 = document.getElementById('u178');

var u140 = document.getElementById('u140');
gv_vAlignTable['u140'] = 'center';
var u196 = document.getElementById('u196');
gv_vAlignTable['u196'] = 'center';
var u335 = document.getElementById('u335');

var u23 = document.getElementById('u23');

var u154 = document.getElementById('u154');

var u264 = document.getElementById('u264');

var u371 = document.getElementById('u371');

var u203 = document.getElementById('u203');

u203.style.cursor = 'pointer';
if (bIE) u203.attachEvent("onclick", Clicku203);
else u203.addEventListener("click", Clicku203, true);
function Clicku203(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u202','hidden','fade',500);

}

}

var u181 = document.getElementById('u181');

var u84 = document.getElementById('u84');
gv_vAlignTable['u84'] = 'top';
var u258 = document.getElementById('u258');

var u320 = document.getElementById('u320');

u320.style.cursor = 'pointer';
if (bIE) u320.attachEvent("onclick", Clicku320);
else u320.addEventListener("click", Clicku320, true);
function Clicku320(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u319','hidden','fade',500);

}

}

var u4 = document.getElementById('u4');
gv_vAlignTable['u4'] = 'top';
var u217 = document.getElementById('u217');

if (bIE) u217.attachEvent("onfocus", Focusu217);
else u217.addEventListener("focus", Focusu217, true);
function Focusu217(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u218','','fade',500);

}

}

var u195 = document.getElementById('u195');

u195.style.cursor = 'pointer';
if (bIE) u195.attachEvent("onclick", Clicku195);
else u195.addEventListener("click", Clicku195, true);
function Clicku195(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u194','hidden','fade',500);

}

}

var u225 = document.getElementById('u225');

u225.style.cursor = 'pointer';
if (bIE) u225.attachEvent("onclick", Clicku225);
else u225.addEventListener("click", Clicku225, true);
function Clicku225(e)
{
windowEvent = e;


if (true) {

	self.location.href="pagina_de_inicio.html" + GetQuerystring();

}

}

var u41 = document.getElementById('u41');
gv_vAlignTable['u41'] = 'top';
var u334 = document.getElementById('u334');

if (bIE) u334.attachEvent("onfocus", Focusu334);
else u334.addEventListener("focus", Focusu334, true);
function Focusu334(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u335','','fade',500);

}

}

var u153 = document.getElementById('u153');

if (bIE) u153.attachEvent("onfocus", Focusu153);
else u153.addEventListener("focus", Focusu153, true);
function Focusu153(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u154','','fade',500);

}

}

if (window.OnLoad) OnLoad();
